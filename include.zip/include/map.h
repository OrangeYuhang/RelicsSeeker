#ifndef MAP_H
#define MAP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "../include/player.h"
#include "../include/backpack.h"
#include "../include/commontypes.h"


// ��Ұ���ڴ�С
#define VIEW_WIDTH 11
#define VIEW_HEIGHT 9

// ������ͼ��ά��
#define MAP_WIDTH 30
#define MAP_HEIGHT 20
#define MAX_LAYERS 3

// ����ͼ����
#define MAX_MAPS 5

// ��ͼԪ������
typedef enum {
    MAP_EMPTY,
    MAP_WALL,
    MAP_TREE,
    MAP_RIVER,
    MAP_GRASS,
    MAP_PATH,
    MAP_TREASURE,
    MAP_EVENT,
    MAP_ENTRANCE,
    MAP_STAIR,
    MAP_NPC,
    MAP_MONSTER,
    MAP_SHOP
} MapElement;

// �¼�����
typedef enum {
    MAP_EVENT_NONE,
    MAP_EVENT_HEAL,
    MAP_EVENT_TRAP,
    MAP_EVENT_RIDDLE,
    MAP_EVENT_BATTLE,
    MAP_EVENT_FIND_ITEM,
    MAP_EVENT_FIND_GOLD,
    MAP_EVENT_QUEST
} MapEventType;

// ��������
typedef enum {
    TREASURE_COINS,
    TREASURE_ITEM,
    TREASURE_RELIC,
    TREASURE_KEY
} TreasureType;

// ��ͼ��Ԫ
typedef struct {
    MapElement element;
    MapEventType eventType;
    int eventValue;
    int itemId;            // ��ƷID���������Ʒ�¼���
    char description[100];
    bool isTriggered;
    bool isExplored;

    // �������
    TreasureType treasureType;
    int treasureValue;
    bool isOpened;
} MapCell;

// ������ͼ��
typedef struct {
    MapCell cells[MAP_HEIGHT][MAP_WIDTH];
    char layerName[30];
    int layerNumber;
} MapLayer;

// �����Ķ���ͼ
typedef struct {
    MapLayer layers[MAX_LAYERS];
    char mapName[50];
    char mapDescription[200];
    int difficulty;
    int totalLayers;
    int startLayer;
    int startX, startY;
    bool isUnlocked;
    int unlockLevel;  // ��������ȼ�
} MultiLayerMap;

// ��ͼϵͳ
typedef struct {
    MultiLayerMap maps[MAX_MAPS];
    int totalMaps;
    int selectedMapIndex;
    bool isSelectingMap;

    // ��ǰ��Ϸ״̬
    Player* player;
    Backpack* backpack;
    int currentMapIndex;
    int currentLayer;

    // ��Ϸͳ��
    int treasuresFound;
    int eventsTriggered;
    int monstersDefeated;
} MapSystem;

// ��ʼ������
void initMapSystem(MapSystem* map, Player* player, Backpack* backpack);
void cleanupMapSystem(MapSystem* map);

// ��ͼѡ�����
void runMapSelection(MapSystem* map);
void displayMapSelection(MapSystem* map);
int handleMapSelectionInput(MapSystem* map);

// ��Ϸ�ڵ�ͼ̽��
//bool canMoveTo(MapSystem* map, int x, int y, int layer);
void runMapExploration(MapSystem* map);
void displayMapView(MapSystem* map);
void displayPlayerStatus(MapSystem* map);
void mapdisplayControls(MapSystem* map);
bool movePlayerInMap(MapSystem* map, int dx, int dy);
void interactCurrentCell(MapSystem* map);
void triggerEvent(MapSystem* map, MapCell* cell);
void openTreasure(MapSystem* map, MapCell* cell);
void changeLayer(MapSystem* map, int newLayer);

// ���ߺ���
MapCell* getCurrentCell(MapSystem* map);
char getElementChar(MapElement element);
const char* getElementName(MapElement element);
bool canMoveTo(MapSystem* map, int x, int y, int layer);

// ��ͼ���ɺ���
void generateForestMap(MultiLayerMap* map);
void generateCaveMap(MultiLayerMap* map);
void generateRuinsMap(MultiLayerMap* map);

#endif // MAP_H