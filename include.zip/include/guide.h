#ifndef GUIDE_H
#define GUIDE_H

#include <stdio.h>
#include <conio.h>

// 游戏指南函数
void showGameGuide(void);
void displayGuidePage(int page);
int handleGuideInput(int* page);

#endif // GUIDE_H