#include "../include/encyclopedia.h"
#include <windows.h>

// 清屏函数
static void clearScreen(void) {
    system("cls");
}

// 设置颜色
static void setColor(int color) {
#ifdef _WIN32
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
#endif
}

// 显示图鉴菜单
void displayEncyclopediaMenu(int selected) {
    clearScreen();
    
    setColor(11);
    printf("═══════════════════════════════════════════\n");
    printf("             图鉴系统\n");
    printf("═══════════════════════════════════════════\n\n");
    setColor(7);
    
    const char* options[] = {"物品图鉴", "怪物图鉴", "遗物图鉴", "成就图鉴", "返回"};
    
    for (int i = 0; i < 5; i++) {
        if (i == selected) {
            setColor(14);
            printf("  ▶ %s\n", options[i]);
            setColor(7);
        } else {
            printf("    %s\n", options[i]);
        }
    }
    
    setColor(11);
    printf("\n═══════════════════════════════════════════\n");
    setColor(14);
    printf("操作: W/S键选择 ↑/↓ | 回车键确认 | Q键返回\n");
    setColor(7);
}

// 显示物品图鉴
void displayItemsEncyclopedia(int page) {
    clearScreen();
    
    setColor(11);
    printf("═══════════════════════════════════════════\n");
    printf("           物品图鉴 (第%d页/共2页)\n", page + 1);
    printf("═══════════════════════════════════════════\n\n");
    setColor(7);
    
    if (page == 0) {
        printf("💊 治疗类物品：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• 初级治疗药水\n");
        printf("  效果：恢复50点生命值\n");
        printf("  价格：50金币\n");
        printf("  用途：战斗后恢复生命\n");
        printf("\n• 中级治疗药水\n");
        printf("  效果：恢复100点生命值\n");
        printf("  价格：80金币\n");
        printf("  用途：紧急治疗\n");
        printf("\n• 高级治疗药水\n");
        printf("  效果：恢复200点生命值\n");
        printf("  价格：150金币\n");
        printf("  用途：大量恢复生命\n");
    } else {
        printf("🔧 工具类物品：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• 低级维修套件\n");
        printf("  效果：修复遗物20%%损坏\n");
        printf("  成功率：40%%\n");
        printf("  价格：100金币\n");
        printf("\n• 中级维修套件\n");
        printf("  效果：修复遗物35%%损坏\n");
        printf("  成功率：70%%\n");
        printf("  价格：200金币\n");
        printf("\n• 高级维修套件\n");
        printf("  效果：修复遗物50%%损坏\n");
        printf("  成功率：90%%\n");
        printf("  价格：400金币\n");
        printf("\n• 背包扩展券\n");
        printf("  效果：增加背包容量10格\n");
        printf("  价格：300金币\n");
        printf("  用途：扩展背包空间\n");
    }
    
    setColor(11);
    printf("\n═══════════════════════════════════════════\n");
    setColor(14);
    printf("操作: A/D键翻页 ←/→ | Q键返回图鉴菜单\n");
    setColor(7);
}

// 显示怪物图鉴
void displayMonstersEncyclopedia(int page) {
    clearScreen();
    
    setColor(11);
    printf("═══════════════════════════════════════════\n");
    printf("           怪物图鉴 (第%d页/共2页)\n", page + 1);
    printf("═══════════════════════════════════════════\n\n");
    setColor(7);
    
    if (page == 0) {
        printf("🐺 普通怪物：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• 森林狼\n");
        printf("  出现地点：魔法森林\n");
        printf("  难度：★☆☆☆☆\n");
        printf("  掉落：金币20-50，经验30\n");
        printf("  特点：移动速度快\n");
        printf("\n• 洞穴蝙蝠\n");
        printf("  出现地点：地下洞穴\n");
        printf("  难度：★☆☆☆☆\n");
        printf("  掉落：金币15-40，经验25\n");
        printf("  特点：会飞行\n");
        printf("\n• 石头傀儡\n");
        printf("  出现地点：古代遗迹\n");
        printf("  难度：★★☆☆☆\n");
        printf("  掉落：金币30-70，经验40\n");
        printf("  特点：防御力高\n");
    } else {
        printf("🐉 精英怪物：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• 火焰蜥蜴\n");
        printf("  出现地点：火山洞穴\n");
        printf("  难度：★★★☆☆\n");
        printf("  掉落：金币80-150，经验80\n");
        printf("  特点：火属性攻击\n");
        printf("\n• 冰霜巨魔\n");
        printf("  出现地点：冰封遗迹\n");
        printf("  难度：★★★★☆\n");
        printf("  掉落：金币120-200，经验120\n");
        printf("  特点：冰属性攻击，移动缓慢\n");
        printf("\n👑 BOSS怪物：\n");
        printf("• 遗迹守护者\n");
        printf("  出现地点：古代遗迹深处\n");
        printf("  难度：★★★★★\n");
        printf("  掉落：金币500-800，经验300\n");
        printf("  特点：全属性攻击，防御极高\n");
        printf("  特殊奖励：古代神器\n");
    }
    
    setColor(11);
    printf("\n═══════════════════════════════════════════\n");
    setColor(14);
    printf("操作: A/D键翻页 ←/→ | Q键返回图鉴菜单\n");
    setColor(7);
}

// 显示遗物图鉴
void displayRelicsEncyclopedia(int page) {
    clearScreen();
    
    setColor(11);
    printf("═══════════════════════════════════════════\n");
    printf("           遗物图鉴 (第%d页/共2页)\n", page + 1);
    printf("═══════════════════════════════════════════\n\n");
    setColor(7);
    
    if (page == 0) {
        printf("🏺 遗物品质说明：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• C级遗物\n");
        printf("  基础价值：100-300金币\n");
        printf("  修复难度：30%%-50%%\n");
        printf("  出现概率：常见\n");
        printf("\n• B级遗物\n");
        printf("  基础价值：300-600金币\n");
        printf("  修复难度：40%%-60%%\n");
        printf("  出现概率：一般\n");
        printf("\n• A级遗物\n");
        printf("  基础价值：600-1000金币\n");
        printf("  修复难度：50%%-70%%\n");
        printf("  出现概率：稀有\n");
        printf("\n• S级遗物\n");
        printf("  基础价值：1000-2000金币\n");
        printf("  修复难度：60%%-80%%\n");
        printf("  出现概率：非常稀有\n");
    } else {
        printf("💎 著名遗物介绍：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• 龙之戒指 (A级)\n");
        printf("  描述：传说中龙族守护的戒指\n");
        printf("  效果：增加火属性抗性\n");
        printf("  价值：500金币\n");
        printf("  获取方式：森林宝藏\n");
        printf("\n• 古代护身符 (B级)\n");
        printf("  描述：带有神秘符文的护身符\n");
        printf("  效果：提升魔法恢复速度\n");
        printf("  价值：300金币\n");
        printf("  获取方式：洞穴宝藏\n");
        printf("\n• 精灵之泪 (S级)\n");
        printf("  描述：精灵的眼泪结晶\n");
        printf("  效果：蕴含强大的自然能量\n");
        printf("  价值：1500金币\n");
        printf("  获取方式：遗迹深层宝藏\n");
        printf("\n• 古代神器 (SSS级)\n");
        printf("  描述：传说中的神器\n");
        printf("  效果：具有不可思议的力量\n");
        printf("  价值：5000金币\n");
        printf("  获取方式：击败遗迹守护者\n");
    }
    
    setColor(11);
    printf("\n═══════════════════════════════════════════\n");
    setColor(14);
    printf("操作: A/D键翻页 ←/→ | Q键返回图鉴菜单\n");
    setColor(7);
}

// 显示成就图鉴
void displayAchievementsEncyclopedia(int page) {
    clearScreen();
    
    setColor(11);
    printf("═══════════════════════════════════════════\n");
    printf("           成就图鉴 (第%d页/共2页)\n", page + 1);
    printf("═══════════════════════════════════════════\n\n");
    setColor(7);
    
    if (page == 0) {
        printf("🏆 探索成就：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• 初出茅庐\n");
        printf("  条件：完成第一个地图探索\n");
        printf("  奖励：经验100，金币50\n");
        printf("\n• 冒险家\n");
        printf("  条件：探索所有地图类型\n");
        printf("  奖励：经验300，金币200\n");
        printf("\n• 地图大师\n");
        printf("  条件：完全探索3个不同地图\n");
        printf("  奖励：经验500，金币500\n");
        printf("\n• 宝藏猎人\n");
        printf("  条件：找到10个宝藏\n");
        printf("  奖励：经验200，金币300\n");
        printf("\n• 事件专家\n");
        printf("  条件：触发20个不同事件\n");
        printf("  奖励：经验300，金币400\n");
    } else {
        printf("🎯 战斗成就：\n");
        printf("═══════════════════════════════════════════\n");
        printf("• 怪物杀手\n");
        printf("  条件：击败50只怪物\n");
        printf("  奖励：经验400，金币300\n");
        printf("\n• 精英猎人\n");
        printf("  条件：击败10只精英怪物\n");
        printf("  奖励：经验600，金币500\n");
        printf("\n• BOSS征服者\n");
        printf("  条件：击败遗迹守护者\n");
        printf("  奖励：经验1000，金币1000\n");
        printf("\n• 无伤大师\n");
        printf("  条件：无伤完成一个地图\n");
        printf("  奖励：经验800，金币700\n");
        printf("\n• 连战连胜\n");
        printf("  条件：连续击败20只怪物\n");
        printf("  奖励：经验500，金币400\n");
        printf("\n🔧 收集成就：\n");
        printf("• 收藏家\n");
        printf("  条件：收集所有类型遗物\n");
        printf("  奖励：经验700，金币600\n");
        printf("\n• 修复大师\n");
        printf("  条件：成功修复10次遗物\n");
        printf("  奖励：经验400，金币350\n");
    }
    
    setColor(11);
    printf("\n═══════════════════════════════════════════\n");
    setColor(14);
    printf("操作: A/D键翻页 ←/→ | Q键返回图鉴菜单\n");
    setColor(7);
}

// 处理图鉴输入
int handleEncyclopediaInput(int* selected, int* page, EncyclopediaType* type) {
    int ch = getch();
    
    switch (ch) {
        case 'w':
        case 'W':
            *selected = (*selected - 1 + 5) % 5;
            return 1; // 继续显示菜单
        case 's':
        case 'S':
            *selected = (*selected + 1) % 5;
            return 1; // 继续显示菜单
        case '\r': // 回车键
        case '\n':
            if (*selected == 4) {
                return 0; // 返回主菜单
            } else {
                *type = (EncyclopediaType)*selected;
                *page = 0;
                return 2; // 进入具体图鉴
            }
        case 'q':
        case 'Q':
            return 0; // 返回主菜单
        default:
            return 1; // 继续显示
    }
}

// 处理具体图鉴输入
int handleSpecificEncyclopediaInput(int* page, EncyclopediaType type) {
    int ch = getch();
    
    switch (ch) {
        case 'a':
        case 'A':
            *page = (*page - 1 + 2) % 2;
            return 1; // 继续显示
        case 'd':
        case 'D':
            *page = (*page + 1) % 2;
            return 1; // 继续显示
        case 'q':
        case 'Q':
            return 0; // 返回图鉴菜单
        default:
            return 1; // 继续显示
    }
}

// 显示图鉴系统
void showEncyclopedia(void) {
    int selected = 0;
    int page = 0;
    EncyclopediaType currentType = ENCY_ITEMS;
    int state = 1; // 1:菜单, 2:具体图鉴, 0:返回
    
    while (state > 0) {
        if (state == 1) {
            // 显示菜单
            displayEncyclopediaMenu(selected);
            state = handleEncyclopediaInput(&selected, &page, &currentType);
        } else if (state == 2) {
            // 显示具体图鉴
            switch (currentType) {
                case ENCY_ITEMS:
                    displayItemsEncyclopedia(page);
                    break;
                case ENCY_MONSTERS:
                    displayMonstersEncyclopedia(page);
                    break;
                case ENCY_RELICS:
                    displayRelicsEncyclopedia(page);
                    break;
                case ENCY_ACHIEVEMENTS:
                    displayAchievementsEncyclopedia(page);
                    break;
            }
            state = handleSpecificEncyclopediaInput(&page, currentType);
            if (state == 0) {
                state = 1; // 返回菜单
                page = 0;
            }
        }
    }
}